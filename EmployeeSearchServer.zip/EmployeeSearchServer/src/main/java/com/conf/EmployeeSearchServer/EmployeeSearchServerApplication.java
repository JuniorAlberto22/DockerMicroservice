package com.conf.EmployeeSearchServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeSearchServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeSearchServerApplication.class, args);
	}
}
